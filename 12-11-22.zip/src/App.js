import './App.css';
import Todo from './container.js';
//import {useState} from "react";
function App() {
  
  return (
    <div className="App">
      <header className="App-header container">
      <h1 className="head">Todo List</h1>
      <Todo/>
      </header>
       
    </div>
  )
}

export default App;
