import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import MainRouter from './router';

function App() {
  return (
    <div className="App">
      <MainRouter/>
    </div>
  );
}

export default App;
