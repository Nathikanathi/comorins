import { useState } from "react";


function Login(){
    const [email,setEmail]=useState(null);
    const [password,setPassword]=useState(null);
    const Validate=()=>{
        return(
            email=="nathika@gmail.com" && password=="890"?console.log("successfully loged"):null 
        );
    }
    return(
        <>
        <input type="text" onKeyUp={(e)=>setEmail(e.target.value)}></input>
        <input type="password" onKeyUp={(e)=>setPassword(e.target.value)}></input>
        <button onClick={Validate}>login</button>
        </>
    );
}
export default Login; 