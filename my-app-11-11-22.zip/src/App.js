// import logo from './logo.svg';
//import './App.css';
import Head from "./header";
import Login from "./container";
function App() {
  const [islogin,setIsLogin]=useState(false)
  return (
    <div className="App">
      <header className="App-header">
        <Head/>
      </header>
      
        <Login/>
      
    </div>
  );
}

export default App;
